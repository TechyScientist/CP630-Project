package net.johnnyconsole.cp630.project.client.util;

public class AccessLevel {
    public static final int ACCESS_STANDARD = 0,
                            ACCESS_ELEVATED = 1;
}
