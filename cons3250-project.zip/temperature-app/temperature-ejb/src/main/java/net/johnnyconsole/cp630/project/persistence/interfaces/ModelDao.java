package net.johnnyconsole.cp630.project.persistence.interfaces;

import net.johnnyconsole.cp630.project.persistence.Model;

public interface ModelDao {

    Model getModel(String name);
}
